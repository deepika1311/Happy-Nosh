<html>
<head>
<title>Happy Nosh</title>
<link rel="Stylesheet" type="text/css" href="ppl.css">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
rel="stylesheet">
</head>
<body>
<div class="container">
<div class="Restaurant">
<h1>Restaurants<h1>
</div>
<div class="row">
<div class="col-md-3 text-center">
<div class="icon">
<i class="fa fa-desktop"></i>
</div>
<h3>Bharti Foods</h3>
<ul>
<li>$190 for one table.</li>  
<li>$250 for two table.</li>
<li>$450 for book the kitty Party.</li>
<li>$750 for book the Marriage Hall.</li>
</ul>
<br>
</button> 
<a class="nav-link" href="payment.php" >PAY NOW</a>
</div>
<div class="col-md-3 text-center">
<div class="icon">
<i class="fa fa-tablet"></i>
</div>
<h3>Royal Bharti Foods</h3>
<ul>
<li>$200 for one table.</li>  
<li>$350 for two table.</li>
<li>$400 for book the kitty Party.</li>
<li>$700 for book the Marriage Hall.</li>
</ul>
<br>
</button> 
<a class="nav-link" href="payment.php" >PAY NOW</a>
</div>

<div class="col-md-3 text-center">
<div class="icon">
<i class="fa fa-line-chart"></i>
</div>
<h3>Brijwasi</h3>
<ul>
<li>$200 for one table.</li>  
<li>$350 for two table.</li>
<li>$550 for book the kitty Party.</li>
<li>$850 for book the Marriage Hall.</li>
</ul>
<br>
</button> 
<a class="nav-link" href="payment.php" >PAY NOW</a>
</div>

<div class="col-md-3 text-center">
<div class="icon">
<i class="fa fa-paint-brush"></i>
</div>
<h3>Hare Krishna Orchid</h3>
<ul>
<li>$210 for one table.</li>  
<li>$390 for two table.</li>
<li>$400 for book the kitty Party.</li>
<li>$950 for book the Marriage Hall.</li>
</ul>
<br>
</button> 
<a class="nav-link" href="payment.php" >PAY NOW</a>
</div>
</body>
</html>
